@echo off
REM Stops whatever is listening on port 8000.
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000 ^| findstr LISTENING') do taskkill /F /PID %%a
echo Server stopped.
