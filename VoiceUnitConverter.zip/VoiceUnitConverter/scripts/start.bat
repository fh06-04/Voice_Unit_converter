@echo off
REM Creates a virtual environment on first run, installs dependencies, starts the server.
cd /d "%~dp0.."
if not exist venv (
    echo Creating virtual environment...
    python -m venv venv || (echo Python not found. Install Python 3.11+ and add it to PATH. & pause & exit /b 1)
)
call venv\Scripts\activate
pip install -q -r requirements.txt
if not exist .env copy .env.example .env >nul
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000/"
python main.py
