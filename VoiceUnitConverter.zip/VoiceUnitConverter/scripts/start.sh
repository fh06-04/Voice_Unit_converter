#!/usr/bin/env bash
# macOS / Linux launcher: creates a venv on first run, installs deps, starts the server.
set -e
cd "$(dirname "$0")/.."
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
[ -f .env ] || cp .env.example .env
python main.py
