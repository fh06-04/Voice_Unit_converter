# Voice Unit Converter

A voice-activated unit converter built with **FastAPI**, **HTML/JS/CSS** and **Python**.
Say "convert twenty five kilometers to miles" and get the answer on screen and out loud.

## Features

- Voice input using the browser's Web Speech API (Chrome / Edge)
- Natural-language parser: understands digits *and* spoken numbers ("two point five", "one thousand two hundred")
- Safe parsing, with no `eval()` anywhere
- 7 categories, 40+ units: length, mass, volume, temperature, speed, time, digital storage
- Phrase styles: "convert 5 km to miles", "how many feet in a mile", "what is 100 fahrenheit in celsius"
- Keyboard and dropdown fallback input
- Spoken result (text-to-speech), toggleable
- Conversion history stored in SQLite, click an entry to run it again
- Automated tests (pytest)

## Project structure

```
main.py            FastAPI app + routes
converter.py       Parser and conversion logic
database.py        SQLite history
config.py          Settings from environment variables
logging_config.py  Logging setup
static/            index.html, style.css, app.js
scripts/           start.bat, stop.bat, start.sh
tests/             pytest suite
```

## Run it

**Windows:** double-click `scripts/start.bat`. It creates a virtual environment, installs dependencies and opens the browser at http://127.0.0.1:8000/.

**macOS / Linux:** `./scripts/start.sh`

**Manually:**
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Stop the server with `Ctrl+C` (or `scripts/stop.bat` on Windows).

## Using it

Click **Start listening** and say, for example:

- "convert 5 kilometers to miles"
- "how many feet in a mile"
- "100 fahrenheit in celsius"
- "two point five liters to milliliters"

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

## API

| Method | Path | Description |
| ------ | ---- | ----------- |
| POST | `/api/convert` | `{"text": "5 km to miles"}` → result (422 with `detail` on failure) |
| GET | `/api/units` | Units grouped by category |
| GET | `/api/history` | Recent conversions |
| DELETE | `/api/history` | Clear history |
| GET | `/health` | Health check |

Interactive docs are at `/docs`.

## Deploying (e.g. Render)

- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Microphone access requires **HTTPS** (or `localhost`), which hosts like Render provide by default.
- Free hosts have a temporary disk, so SQLite history may reset on redeploy.

## Troubleshooting

- **Microphone blocked:** click the lock icon in the address bar and allow the microphone.
- **"Voice input isn't supported":** use Chrome or Edge. Firefox lacks the Web Speech API. Typed input still works.
- **Speech needs internet:** Chrome sends audio to Google's speech service.
- **Port in use:** change `PORT` in `.env`.
- **Python not found:** install Python 3.11+ and tick "Add to PATH".

## Notes

Digital storage uses decimal units (1 KB = 1000 bytes); volume uses US customary units.
